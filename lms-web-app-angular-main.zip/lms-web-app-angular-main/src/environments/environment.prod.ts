export const environment = {
  production: true,
  apiBaseUrl:'https://api-lms-zultech.windows.zephost.com'
};
