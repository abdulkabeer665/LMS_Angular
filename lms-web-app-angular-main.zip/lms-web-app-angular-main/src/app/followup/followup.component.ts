import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/Services/http-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-followup',
  templateUrl: './followup.component.html',
  styleUrls: ['./followup.component.css']
})
export class FollowupComponent implements OnInit {
  InsertFollowupform : FormGroup;
  data=[];
  editRowNum=-1;
  editRow;
  searchText:string = '';
  searchvalue:string = 'NameEn';
  totalCount:0;
  pageSizeOptions: number[] = [1,5, 10, 25, 100];

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:any){
    this.load(+(event.pageIndex+1),event.pageSize)
   
  }
  constructor(public httpService: HttpService,private formBuilder: FormBuilder,private dialog:MatDialog,
    private _snackBar: MatSnackBar) {
   
   }

  ngOnInit(): void {
    this.load(1,25);
    this.InsertFollowupform = this.formBuilder.group({
      LookUpDataCode: 'Followup_Master',
      Code: '',
      NameEn : ['', Validators.required],
      NameAr : '',
  });
  }

  load(pageNumber, pageSize){
    this.httpService.getData('/api/Setup/getLookupDatabyCode?Code=Followup_Master'+"&PageNumber="+pageNumber+"&RowsOfPage="+pageSize).subscribe((x:any ) => {
      this.data=[];
      if(x && x.data && x.data['length']){
        this.data = x.data
        this.totalCount=x.data["length"];
      }
    })
  }

  InsertFollowup(){
    this.InsertFollowupform.controls['Code'].setValue('product_'+((this.InsertFollowupform.controls['NameEn'].value+'').toLowerCase()))
    this.httpService.postData('/api/Setup/insertLookup',this.InsertFollowupform.value).subscribe((x =>{
      this.load(1,25);
    }))
  }
  startEditing(rowNumber,data){
    this.editRow=data;
    this.editRowNum=rowNumber;
  }
  validationOnEditMode=false;
  updateRow(){
    this.validationOnEditMode=false;
    if(this.editRow.NameEn && this.editRow.NameEn!=''){
      this.updateFollowUp();
    }else{
      this.validationOnEditMode=true;;
    }
  }
  updateFollowUp(){
    this.editRow.Code='followup_'+((this.editRow.NameEn+'').toLowerCase())
    this.httpService.postData('/api/Setup/updateLookupbyId?Id='+this.editRow.Id,this.editRow).subscribe((x =>{
      this.load(1,25);
      this.cancelEditing();
    }))
  }
  cancelEditing(){
    this.editRowNum=-1;
    this.editRow=undefined;
    
  }
  deleteFollowUp(id,){
    this.dialog.open(DeleteEventComponent,{
      width:'390px',
      data:{
        message:'Are you sure to delete?'
      }
  
    }).afterClosed().subscribe((res:any)=>{
      if(res === true){
         this.httpService.deleteData(`/api/Setup/deleteLookupbyId?Id=${id}`).subscribe((data:any)=>{
          console.log("Record Deleted:",data);
          if(data && data.result=='success'){
            this.InsertFollowupform.reset();
            this.load(1,25);
          }else if(data && data.result=='faild'){
            this.openSnackBar("Cannot Delete Record!");
          }
          
        })
      }
    });
  }
  openSnackBar(message: string) {
    this._snackBar.open(message,'ok',{
      duration: 3000
    });
  }
  
}
