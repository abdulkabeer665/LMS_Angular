import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/Services/http-service.service';

@Component({
  selector: 'app-typography',
  templateUrl: './typography.component.html',
  styleUrls: ['./typography.component.css']
})
export class TypographyComponent implements OnInit {

  data=[];
  constructor(public httpService: HttpService) {
    this.httpService.getData('/api/Setup/getRoles').subscribe((x:any ) => {
      this.data = x.data
    })
   }


  ngOnInit() {
  }

}
