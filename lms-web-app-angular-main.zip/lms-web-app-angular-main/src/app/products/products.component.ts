import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
import { HttpService } from 'app/Services/http-service.service';
import * as e from 'express';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  // leadsData=[ {
  //   Id: 5,
  //   ContactName: "dfsdfasdfd",
  //   CompanyName: "afdfaf",
  //   Position: "adfedfad",
  //   CountryId: 2,
  //   Email: "fasdffad",
  //   Mobile: "fdadadf",
  //   Tell: "dfadf",
  //   Address: "afasdfasdfasdf",
  //   FollowedBy: 9,
  //   RecivedBy: 9,
  //   EventId: 1016,
  //   PriorityId: 1,
  //   ProductId: "1,2,2,3,3",
  //   IndustryId: "1,2,2,3,3",
  //   FollowUpTypeId: "2",
  //   Date: "2022-11-04T02:02:09.210",
  //   isDeleted: false,
  //   CreatedAt: "2022-11-03T23:11:36.723",
  //   CreatedBy: 2,
  //   ModifiedAt: "2022-11-03T23:11:36.723"
  // },{
  // Id: 6,
  //   ContactName: "dfsdfasdfd",
  //   CompanyName: "afdfaf",
  //   Position: "adfedfad",
  //   CountryId: 2,
  //   Email: "fasdffad",
  //   Mobile: "fdadadf",
  //   Tell: "dfadf",
  //   Address: "afasdfasdfasdf",
  //   FollowedBy: 9,
  //   RecivedBy: 9,
  //   EventId: 1016,
  //   PriorityId: 1,
  //   ProductId: "1,2,2,3,3",
  //   IndustryId: "1,2,2,3,3",
  //   FollowUpTypeId: "2",
  //   Date: "2022-11-04T02:02:09.210",
  //   isDeleted: false,
  //   CreatedAt: "2022-11-03T23:11:36.723",
  //   CreatedBy: 2,
  //   ModifiedAt: "2022-11-03T23:11:36.723"
  // }];
  InsertProductform : FormGroup;
  data=[];
  editRowNum=-1;
  editRow;
  totalCount:0;
  searchvalue:string = 'NameEn';
  searchText:string = '';
  pageSizeOptions: number[] = [5, 10, 25, 100];

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:any){
    this.load(+(event.pageIndex+1),event.pageSize)
   
  }
  constructor(public httpService: HttpService,private formBuilder: FormBuilder,private dialog:MatDialog,
    private _snackBar: MatSnackBar) {

   }

  ngOnInit(): void {
    this.load(1,5);
    this.InsertProductform = this.formBuilder.group({
      LookUpDataCode: 'Product_Master',
      Code: '',
      NameEn : ['', Validators.required],
      NameAr : '',
  });
  }
  load(pageSize, pageNumber){
    this.httpService.getData('/api/Setup/getLookupDatabyCode?Code=Product_Master'+"&PageNumber="+pageNumber+"&RowsOfPage="+pageSize).subscribe((x:any ) => {
      this.data=[];
      if(x && x.data && x.data['length']){
        this.data = x.data
        this.totalCount = x.data['length']
      }
    })
  }
  InsertProduct(){
    this.InsertProductform.controls['Code'].setValue('product_'+((this.InsertProductform.controls['NameEn'].value+'').toLowerCase()))
    this.httpService.postData('/api/Setup/insertLookup',this.InsertProductform.value).subscribe((x =>{
      this.load(1,5);
    }))
  }
  startEditing(rowNumber,data){
    this.editRow=data;
    this.editRowNum=rowNumber;
  }
  validationOnEditMode=false;
  updateRow(){
    this.validationOnEditMode=false;
    if(this.editRow.NameEn && this.editRow.NameEn!=''){
      this.updateProduct();
    }else{
      this.validationOnEditMode=true;;
    }
  }
  updateProduct(){
    this.editRow.Code='product_'+((this.editRow.NameEn+'').toLowerCase())
    this.httpService.postData('/api/Setup/updateLookupbyId?Id='+this.editRow.Id,this.editRow).subscribe((x =>{
      this.load(1,5);
      this.cancelEditing();
    }))
  }
  cancelEditing(){
    this.editRowNum=-1;
    this.editRow=undefined;
    
  }
  deleteProducts(id,){
    this.dialog.open(DeleteEventComponent,{
      width:'390px',
      data:{
        message:'Are you sure to delete?'
      }
  
    }).afterClosed().subscribe((res:any)=>{
      if(res === true){
         this.httpService.deleteData(`/api/Setup/deleteLookupbyId?Id=${id}`).subscribe((data:any)=>{
          console.log("Record Deleted:",data);
          if(data && data.result=='success'){
            this.InsertProductform.reset();
            this.load(1,5);
          }else if(data && data.result=='faild'){
            this.openSnackBar("Cannot Delete Record!");
          }
          
        })
      }
    });
  }
  openSnackBar(message: string) {
    this._snackBar.open(message,'ok',{
      duration: 3000
    });
  }
  
}


        
       