import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from 'app/Services/http-service.service';
@Component({
  selector: 'app-userrole',
  templateUrl: './userrole.component.html',
  styleUrls: ['./userrole.component.scss']
})
export class UserroleComponent implements OnInit {
  data=[];
  searchText:string = '';
  searchvalue:string = 'Name';
  totalCount:0;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  params:any;

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:any){
    this.load(+(event.pageIndex+1),event.pageSize)
   
  }
  constructor(public httpService: HttpService,private router: Router) {
    this.load(1,25)
   }

  ngOnInit(): void {
    this.load(1,25)
  }
  SendID(Id:any){
    this.router.navigate(['/rolerights/'+Id]);
    console.log(Id);
    
  }

  load(pageNumber,pageSize){
    this.httpService.getData('/api/Setup/getRoles?PageNumber='+pageNumber+"&RowsOfPage="+pageSize).subscribe((x:any ) => {
      this.data = x.data
      this.totalCount = x.data['length']
    })
  }

  
}
