import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  filterdata = [];
  transform(value: any, searchText:string , searchvalue:string){
    if(value?.length === 0 || searchText === '' ){
      return value;
    }else{
      if(searchvalue === 'EventName'){
        return value.filter((data:any)=>
        data.EventName.toLowerCase().includes(searchText.toLowerCase()));
      }
      if(searchvalue === 'ContactName'){
        return value.filter((data:any)=>
        data.ContactName.toLowerCase().includes(searchText.toLowerCase()));
      }
      if(searchvalue === 'Name'){
        return value.filter((data:any)=>
        data.Name.toLowerCase().includes(searchText.toLowerCase()));
      }
      if(searchvalue === 'Name'){
        return value.filter((data:any)=>
        data.FullName.toLowerCase().includes(searchText.toLowerCase()));
      }
      else{
        return value.filter((data:any) => 
        data.NameEn.toLowerCase().includes(searchText.toLowerCase()));
      }
    }
  }
}
