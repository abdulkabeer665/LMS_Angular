import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';

@Injectable({
  providedIn: 'root'
})
export class UtilService {
  constructor(public dialog: MatDialog) { }

  openDialog(msg:any){
    this.dialog.open(DeleteEventComponent,{
      width:'390px',
      disableClose:true,
      data:{
        message:msg
      }
    })
  }

}
