
export class AppConstants { 

public static APP_ROUTES = {

    dashboard : {
        default : 'dashboard',
        dashboard : 'dashboard'
    },

    leads : {
        default : 'lms-leads',
        LeadsOverview : 'leads-overview',
        createLeads : 'create-Leads',
        updateLeads : 'update-leads'
    },

    events : {
        default : 'lms-events',
        EventOverview : 'event-overview',
        CreateEvent: 'create-event',
        UpdateEvent : 'update-event'

    }
}
}