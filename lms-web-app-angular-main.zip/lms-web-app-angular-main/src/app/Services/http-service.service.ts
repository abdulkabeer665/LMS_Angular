import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  baseUrl = environment.apiBaseUrl
  constructor(private http: HttpClient) { }
  // Get Data Method From API
  getData(url: string) {
    return this.http.get(this.baseUrl + url); 
  }
  getDataV1(url: string) {
    return this.http.get(url);
  }
  // Post Data Method
  postData(url: string, payLoad: any) {
    return this.http.post(this.baseUrl + url, payLoad);
  }
  // Update/Put Data Method
  updateData(url: string, payload: any) {
    return this.http.put(this.baseUrl + url, payload)
  }
  // Delete Data method actually archiving method
  deleteData(url: string) {
    return this.http.delete(this.baseUrl + url);
  }
  changePassword(url, data: any) {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${data.token ? data.token : ""}`
    });
    let options = { headers: headers };
    let payLoad = { NewPassword: data.value ? data.value : "" };
    return this.http.post(this.baseUrl + url, payLoad, options);
  }

}
