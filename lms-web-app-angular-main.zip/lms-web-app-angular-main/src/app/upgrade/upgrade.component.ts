import { Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { PageEvent } from "@angular/material/paginator";
import { Router } from "@angular/router";
import { DeleteLeadsComponent } from "app/dialog/delete-leads/delete-leads.component";
import { HttpService } from "app/Services/http-service.service";
import { LoaderService } from "app/Services/loader.service";

@Component({
  selector: "app-upgrade",
  templateUrl: "./upgrade.component.html",
  styleUrls: ["./upgrade.component.css"],
})
export class UpgradeComponent implements OnInit {
  LeadsData: any;
  totalCount=0;
  totalresult:string;
  page:number;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  searchText:string='';
  key:string = 'ContactName';

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:PageEvent){
    this.getAllLeads(+(event.pageIndex+1),event.pageSize)
  }
  constructor(
    public httpservice: HttpService,
    public router: Router,
    private loader: LoaderService,private dialog:MatDialog
  ) {}

  ngOnInit() {
    this.getAllLeads(1,5);
   
  }

  public getAllLeads(pageNumber,pageSize) {
    this.httpservice
      .getData("/api/Setup/getAllLeads?PageNumber="+pageNumber+"&RowsOfPage="+pageSize)
      .subscribe((data) => {
        this.totalCount=data["data"]["total"];
        this.LeadsData = data["data"]["data"];
        console.log(this.LeadsData)
        
      });
  }

  public updateLeads(i) {
    this.router.navigate(["/edit-leads"], { state: { Lead: i } });
  }
  deletelead(id:any){
    this.dialog.open(DeleteLeadsComponent,{
      width:'390px',
      data:{
        message:'Are you sure to delete this lead ?'
      }
  
    }).afterClosed().subscribe((res:any)=>{
      if(res === true){
         this.httpservice.postData(`/api/Setup/deleteLeadbyID?LeadID=${id}`,id).subscribe((data:any)=>{
      this.getAllLeads(1,25);
    })
      }
    });
  }
}
