import { Location } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { HttpService } from "app/Services/http-service.service";
import { environment } from "environments/environment";

@Component({
  selector: "app-edit-leads",
  templateUrl: "./edit-leads.component.html",
  styleUrls: ["./edit-leads.component.css"],
})
export class EditLeadsComponent implements OnInit {
  UpdateLeadForm: FormGroup;
  LeadData: unknown;
  LeadDataToBind: any;
  filePath='';
  countries=[];
  priorities=[];
  products=[];
  industries=[];
  followups=[];
  users=[];
  constructor(
    private route: ActivatedRoute,
    public httpService: HttpService,
    private formBuilder: FormBuilder,
    private router: Router,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.loadAllData();
    this.buildForm();
    this.LeadData = this.location.getState();
    console.log("Leads",this.LeadData);
    if(this.LeadData['Lead'] && this.LeadData['Lead']!=null){
      this.SetLeadData(this.LeadData['Lead']);
      sessionStorage.removeItem('selectedLead');    // localStorage.removeItem('id');
      sessionStorage.setItem('selectedLead',JSON.stringify(this.UpdateLeadForm.value));   // localStorage.setItem('id', noOfClicks);
    }else{
      const lead = JSON.parse(sessionStorage.getItem("selectedLead"));
      console.log("Got From local storage",lead);
      this.SetLeadData(lead);
      //console.log("Selected Field",this.UpdateLeadForm.controls['ProductId'].value)
    }
  }
  buildForm(){
    this.UpdateLeadForm = this.formBuilder.group({
      Id:-1,
      EventId: "",
      LoginUserId: "",
      ContactName: "",
      Position: "",
      CompanyName: "",
      Address: "",
      CountryId: "",
      Mobile: "",
      Email: "",
      Tell: "",
      Fax: "",
      PriorityId: "",
      ProductId: "",
      IndustryId: "",
      FollowupTypeId: "",
      OtherProducts: "",
      OtherFollowUp: "",
      OtherIndustries:"",
      FollowedBy: "",
      RecivedBy: "",
      FilePath:"",
      Remarks:""
    });
  }
SetLeadData(data){
  this.UpdateLeadForm.controls['Id'].setValue(data.Id);
  this.UpdateLeadForm.controls['EventId'].setValue(data.EventId);
  this.UpdateLeadForm.controls['LoginUserId'].setValue(data.LoginUserId);
  this.UpdateLeadForm.controls['ContactName'].setValue(data.ContactName);
  this.UpdateLeadForm.controls['Position'].setValue(data.Position);
  this.UpdateLeadForm.controls['CompanyName'].setValue(data.CompanyName);
  this.UpdateLeadForm.controls['Address'].setValue(data.Address);
  this.UpdateLeadForm.controls['CountryId'].setValue(data.CountryId);
  this.UpdateLeadForm.controls['Mobile'].setValue(data.Mobile);
  this.UpdateLeadForm.controls['Email'].setValue(data.Email);
  this.UpdateLeadForm.controls['Tell'].setValue(data.Tell);
  this.UpdateLeadForm.controls['Fax'].setValue(data.Fax);
  this.UpdateLeadForm.controls['PriorityId'].setValue(data.PriorityId);
  this.UpdateLeadForm.controls['ProductId'].setValue(data.ProductId);
  this.UpdateLeadForm.controls['IndustryId'].setValue(data.IndustryId);
  this.UpdateLeadForm.controls['FollowupTypeId'].setValue(data.FollowUpTypeId);
  this.UpdateLeadForm.controls['OtherProducts'].setValue(data.OtherProducts);
  this.UpdateLeadForm.controls['OtherFollowUp'].setValue(data.OtherFollowUp);
  this.UpdateLeadForm.controls['OtherIndustries'].setValue(data.OtherIndustries);
  this.UpdateLeadForm.controls['FollowedBy'].setValue(data.FollowedBy);
  this.UpdateLeadForm.controls['RecivedBy'].setValue(data.RecivedBy);
  this.UpdateLeadForm.controls['FilePath'].setValue(data.FilePath);
  this.UpdateLeadForm.controls['Remarks'].setValue(data.Remarks);
  this.filePath=environment.apiBaseUrl+data.FilePath;
}
loadAllData(){
  this.loadLookupData('Country_Master').subscribe((x:any)=>{
    if(x && x.data && x.data['length']){
      this.countries=this.appendIdenticalFieldsForSearchControl(x.data);
    }else{
      this.countries=[];
    }
  });
  this.loadLookupData('Priority_Master').subscribe((x:any)=>{
    if(x && x.data && x.data['length']){
      this.priorities=this.appendIdenticalFieldsForSearchControl(x.data);
    }else{
      this.priorities=[];
    }
  });
  this.loadLookupData('Product_Master').subscribe((x:any)=>{
    if(x && x.data && x.data['length']){
      this.products=this.appendIdenticalFieldsForSearchControl(x.data);
    }else{
      this.products=[];
    }
  });
  this.loadLookupData('Industry_Master').subscribe((x:any)=>{
    if(x && x.data && x.data['length']){
      this.industries=this.appendIdenticalFieldsForSearchControl(x.data);
    }else{
      this.industries=[];
    }
  });
  this.loadLookupData('Followup_Master').subscribe((x:any)=>{
    if(x && x.data && x.data['length']){
      this.followups=this.appendIdenticalFieldsForSearchControl(x.data);
    }else{
      this.followups=[];
    }
  });
  this.loadAllUsers();
}
loadLookupData(code){
  return this.httpService.getData('/api/Setup/getLookupDatabyCode?Code='+code);
}
loadAllUsers(){
  this.httpService.getData('/api/Setup/getAllUsers').subscribe(data=> {
    this.users=data['data'];
  })
}
isChecked(fieldName,id){
  return (((this.UpdateLeadForm.controls[fieldName].value+'').split(",")).includes(id+""));
}
isOtherChecked(fieldName){
  return (((this.UpdateLeadForm.controls[fieldName].value+'').split(",")).includes(this.other_Ids[fieldName]));
}
setAll(state:boolean,fieldName,id){
  if(state){
    const _temp=(this.UpdateLeadForm.controls[fieldName].value+','+id);
    this.UpdateLeadForm.controls[fieldName].setValue(_temp);
  }else{
    let _temp:any[]=(this.UpdateLeadForm.controls[fieldName].value).split(",");
    const _itemIndex=_temp.findIndex(fi=>(fi==id));
    if(_itemIndex!==-1){
      _temp.splice(_itemIndex,1);
      this.UpdateLeadForm.controls[fieldName].setValue(_temp.toString());
    }
    
  }
}
 public updateLeads() {
  console.log("Compare IDs",this.UpdateLeadForm.value)
   this.httpService.postData('/api/Setup/updateLeadbyID?LeadId='+this.UpdateLeadForm.controls['Id'].value,this.UpdateLeadForm.value).subscribe(data=> {
     if (data) {
      console.log("Data Daved",data)
       this.router.navigate(['/upgrade'])
     }
   })
 }
 other_Ids={
  FollowupTypeId: "",
  ProductId: "",
  IndustryId: "",
 }
 private appendIdenticalFieldsForSearchControl(data){
  let _tempArray:any[]= data.map(m=>{
    let temp=Object.assign({},m);
    temp['name']=m.NameEn;
    return temp;
  });
  const _otherElementIndex=_tempArray.findIndex(fi=>(fi.Code=='Follow_Other' || fi.Code=='Product_Other' || fi.Code=='Industry_Other'));
  if(_otherElementIndex!==-1){
    const _tempOterObj=_tempArray.splice(_otherElementIndex,1);
    _tempArray=_tempArray.concat(_tempOterObj);
    if(_tempOterObj[0].Code=='Product_Other'){
      this.other_Ids.ProductId=(_tempOterObj[0].Id+"");
      
    }
    if(_tempOterObj[0].Code=='Follow_Other'){
      this.other_Ids.FollowupTypeId=(_tempOterObj[0].Id+"");
      
    }
    if(_tempOterObj[0].Code=='Industry_Other'){
      this.other_Ids.IndustryId=(_tempOterObj[0].Id+"");
      
    }
  }
  return _tempArray;
}
}
