import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from 'app/Services/http-service.service';

@Component({
  selector: 'lms-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  public getAllEventsURL = '/api/Setup/getAllEvents'

  columns = [
    { title: 'Name', valueKey: 'name'  },
    { title: 'DOB', valueKey: 'dob' }
  ]

  data = [
    { name: 'Ahsan', dob: '30-09-1995' },
    { name: 'Fahad', dob: '06-10-1995' },
  ]

  constructor(private router: Router,
    public httpService : HttpService) { }

  ngOnInit() {
    this.getAllEvents();
  }

    public createEvent(): any {
      this.router.navigate(['/create-event'])
    }

    public getAllEvents() {
      this.httpService.getData(this.getAllEventsURL).subscribe(data=>{
      })
    }
}
