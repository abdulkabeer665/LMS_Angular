import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-overview',
  templateUrl: './event-overview.component.html',
  styleUrls: ['./event-overview.component.scss']
})
export class EventOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
