import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateEventComponent } from './create-event/create-event.component';
import { UpdateEventComponent } from './update-event/update-event.component';
import { EventOverviewComponent } from './event-overview/event-overview.component';
import { RouterModule, Routes } from '@angular/router';
import { EventComponent } from './event.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';

const routes: Routes = [
  {
    path: 'lms-event',
    component: EventComponent
  },
  {
    path: 'event-overview',
    component: EventOverviewComponent
  },
  {
    path: 'create-event',
    component: CreateEventComponent
  },
  {
    path: 'update-event',
    component: UpdateEventComponent
  }
]

@NgModule({
  declarations: [
    CreateEventComponent,
    UpdateEventComponent,
    EventOverviewComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
  ]
})
export class EventModule { }
