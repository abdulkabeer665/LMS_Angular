import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrioritesComponent } from './priorites.component';

describe('PrioritesComponent', () => {
  let component: PrioritesComponent;
  let fixture: ComponentFixture<PrioritesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrioritesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrioritesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
