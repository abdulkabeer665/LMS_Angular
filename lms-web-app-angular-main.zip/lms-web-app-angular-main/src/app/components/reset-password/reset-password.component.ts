import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from 'app/Services/http-service.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  insertForm;
  submitted = false;
  Token;
  showSuccess= false;
  showError= false;
  constructor(private fb: FormBuilder,private service:HttpService,private route:ActivatedRoute,private router:Router) { 
    this.insertForm= this.fb.group({
      password: new FormControl('',[Validators.required,Validators.minLength(6)]),
      confirm_password:new FormControl('',[Validators.required,])
    },{
      validators: this.MustMatch('password','confirm_password')
    })
    this.Token= this.route.snapshot.queryParams['uid'];
  }
  ngOnInit(): void {
 
  }
get f(){
  return this.insertForm.controls;
}
MustMatch(controlName:string,matchName:string){
return (formgroup:FormGroup)=>{
  const control= formgroup.controls[controlName];
  const match= formgroup.controls[matchName];
  if(match.errors && !match.errors.MustMatch){
    return 
  }
  if(control.value!==match.value){
    match.setErrors({MustMatch:true});
  }else{
    match.setErrors(null);
  }
}
}
onSubmit(){
  // console.log(this.insertForm.value);
  this.submitted=true;
  if (this.insertForm.invalid) {
    return;
}
let url='/api/UserAccount/passwordChange';
const data={
  token:this.Token,
  value:this.insertForm.value.password
}
this.service.changePassword(url,data).subscribe((data:any)=>{
  console.log(data);
  if(data.result=='success'){
    this.showSuccess=!this.showSuccess;
    setTimeout(()=>{
this.router.navigate(['login'])
    },2000);
  }else{
    this.showError= !this.showError;
  }
})

}
}
