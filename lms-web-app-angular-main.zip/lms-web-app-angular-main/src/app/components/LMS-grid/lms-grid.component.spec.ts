import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LMSGridComponent } from '../LMS-grid/lms-grid.component'

describe('FooterComponent', () => {
  let component: LMSGridComponent;
  let fixture: ComponentFixture<LMSGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LMSGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LMSGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
