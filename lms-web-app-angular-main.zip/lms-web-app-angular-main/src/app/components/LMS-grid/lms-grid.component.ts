import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { HttpService } from './../../Services/http-service.service';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lms-grid',
  templateUrl: './lms-grid.component.html',
  styleUrls: ['./lms-grid.component.css']
})
export class LMSGridComponent implements OnInit {
  test : Date = new Date();

  columns: any[] = [];
  gridData: any[] = [];
  
  isEdit: boolean = false;
  editIndex: number;

  editForm: FormGroup;
  
  @Input('columns') set setColumns(columns: any[]) {
    this.columns = columns?.length ? columns : [];
  }
  @Input('data') set setData(data: any[]) {
    this.gridData = data?.length ? data : [];
  }
  @Input('apiUrl') apiUrl: string;
  @Input('apiType') apiType: string;
  @Input('apiParams') apiParams: any;

  @Input('gridTitle') gridTitle: string;
  @Input('gridDescription') gridDescription: string;
  @Input('isEditable') isEditable: boolean = true;
  @Input('isDeletable') isDeletable: boolean = true;

  constructor(private _http: HttpService, private _fb: FormBuilder) { }

  ngOnInit() {
    this.apiRequest();
  }

  apiRequest() {

    if (!this.apiUrl || !this.apiType) {
      return false;
    }

    if (this.apiType.toLocaleLowerCase() === 'get') {
      const url = this.apiParams ? (this.apiUrl + this.apiParams) : this.apiUrl;
      this._http.getData(url).subscribe((x: any) => {
        this.gridData = x;
      })
    } else if (this.apiType.toLocaleLowerCase() === 'post') {
      this._http.postData(this.apiUrl, this.apiParams).subscribe((x: any) => {
        this.gridData = x;
      })
    }
    
  }

  edit(data: any, index: number) {
    this.editIndex = index;
  }
  cancel() {
    this.isEdit = false;
    this.editIndex = undefined;
  }

  createForm() {
    this.editForm = this._fb.group({
    })
  }
  createFields(data) {
    return {  };
  }
  

}
