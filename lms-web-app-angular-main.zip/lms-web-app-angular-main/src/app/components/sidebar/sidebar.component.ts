import { Component, OnInit } from '@angular/core';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
    child:any[]
}
export const ROUTES: RouteInfo[] = [
    { path: '/dashboard', title: 'Dashboard',  icon: 'dashboard', class: '',child:[] },
    { path: '/upgrade', title: 'Leads',  icon:'groups', class: '',child:[] },
    { path: '/table-list', title: 'Events',  icon:'content_paste', class: '',child:[]  },
    { path: '/icons', title: 'Setup',  icon:'miscellaneous_services', class: '' ,child:[
      { path: '/places', title: 'Places',  icon:'place', class: '' },
      { path: '/products', title: 'Products',  icon:'category', class: '' },
      { path: '/industries', title: 'Industries',  icon:'factory', class: '' },
      { path: '/priorities', title: 'Priorities',  icon:'sort', class: '' },
      { path: '/followup', title: 'Follow up',  icon:'hail', class: '' },
      { path: '/user-roles', title: 'User Roles',  icon:'badge', class: '' },
    ]},
    { path: '/user-profile', title: 'Users',  icon:'manage_accounts', class: '',child:[] }
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor() { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  }
  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  };
}
