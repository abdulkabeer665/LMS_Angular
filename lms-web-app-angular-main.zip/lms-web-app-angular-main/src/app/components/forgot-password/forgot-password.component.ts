import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpService } from 'app/Services/http-service.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
insertForm;
Email:FormControl;
successMessage: string;
  errorMessage: string;
showSuccess= false;
  showError= false;
  constructor(private fb: FormBuilder,private service:HttpService) { }

  ngOnInit(): void {

    this.Email = new FormControl('',[Validators.required,Validators.email]);
      this.insertForm= new FormGroup({
      Email: this.Email
      })
   
      
  }
onSubmit(){
  // console.log(this.insertForm.value);
  let url='/api/UserAccount/passwordReset';
  this.service.postData(url,this.insertForm.value).subscribe((data:any)=>{
    const result = data.result;
    if(result ==='success'){
      this.showSuccess = !this.showSuccess;
      setTimeout(()=>{
        this.showSuccess=false;
        this.insertForm.reset();
      },5000);
  
     }else{
       this.showError= !this.showError;
       setTimeout(()=>{
        this.showError=false;
        this.insertForm.reset();
      },5000);
     }
   
  })
}
}