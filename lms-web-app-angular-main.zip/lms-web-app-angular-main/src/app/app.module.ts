import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';
import { AppComponent } from './app.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { HttpService } from './Services/http-service.service';
import { AuthService } from './_auth/services/auth.service';
import { APP_BASE_HREF } from '@angular/common';
import { AuthGuard } from './_auth/guards/auth.guard';
import { TokenIntercept } from './_auth/tokenintercept';
import { FakeBackendInterceptor } from './_shared/fakebackend';
import { LogoutComponent } from './components/logout/logout.component';
import { LoginComponent } from './components/login/login.component';
import { UtilService } from './Services/util.service';
import { RegisterUserComponent } from './components/register-user/register-user.component';
import { UserGirdComponent } from './user-profile/user-gird/user-gird.component';
import { UserroleComponent } from './userrole/userrole.component';
import { UserRoleRightsComponent } from './user-role-rights/user-role-rights.component';


import { LoaderService } from './Services/loader.service';
import { HelperService } from './Services/helper.service';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { MatFormFieldModule } from '@angular/material/form-field';






@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    MatFormFieldModule
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    LoginComponent,
    LogoutComponent,
    RegisterUserComponent,
    
    ForgotPasswordComponent,
    ResetPasswordComponent
  
  
    

  ],
  providers: [
    { provide: APP_BASE_HREF, useValue: '/'},
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenIntercept,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: FakeBackendInterceptor,
      multi: true
    },

    HttpService,
    AuthService,
    UtilService,
    LoaderService,
    HelperService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
