import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HelperService } from 'app/Services/helper.service';
import { HttpService } from 'app/Services/http-service.service';
import { map } from 'rxjs';
@Component({
  selector: 'app-edit-event',
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.css']
})
export class EditEventComponent implements OnInit {
  EventData: any;
  EventDataToBind: any;
  updateEvent : FormGroup;
  show:boolean = false;
  countries=[];
  code:string;
  id: any;
  slected_country_id;

  places=[];
  placeId: any;
  constructor(private location: Location,
     public formBuilder : FormBuilder ,
      public httpService : HttpService ,
      private router: Router,
      private route: ActivatedRoute,
      public helperService : HelperService ) {
        
   }
   loadLookupData(code){
    return this.httpService.getData('/api/Setup/getLookupDatabyCode?Code='+code).pipe(map((m:any)=>{
      if(m.data && m.data['length']){
        return m.data;
      }else{
        return [];
      }
    }))
   }
   onCountryChange(value : any){
    this.code = value.Code
    this.id = value.Id
     this.httpService.getData('/api/Setup/getLookupDatabyCode?Code='+this.code).subscribe((x:any ) => {
       this.places = x['data'];
     })
   }
   loadCities(){
    this.loadLookupData(this.updateEvent.controls['CountryCode'].value).subscribe(x=>{
      this.places=x;
      if(this.places.length){
        const _ind=this.countries.findIndex(fi=>(fi.Code==this.updateEvent.controls['CountryCode'].value));
        if(_ind!==-1){
          this.updateEvent.controls['CountryID'].setValue(this.countries[_ind].Id);
          this.code=this.updateEvent.controls['CountryCode'].value;
          this.id=this.countries[_ind].Id;
          this.slected_country_id=this.countries[_ind].Id;
        }
      }
    })
   }
   onPlaceChanges(value : any) {
      this.placeId = value.Id
      this.updateEvent.controls['PlaceId'].setValue(this.placeId)
   }
  ngOnInit(): void {
    this.BuildForm();
    // this.EventData= this.location.getState();
    // this.EventDataToBind = this.EventData?.Event;
    this.loadLookupData('Country_Master').subscribe(x=>{
      this.countries=x;
    });
    this.EventData = this.location.getState();
    if(this.EventData['Event'] && this.EventData['Event']!=null){
      this.SetEventData(this.EventData['Event']);
      sessionStorage.removeItem('selectedEvent');    // localStorage.removeItem('id');
      sessionStorage.setItem('selectedEvent',JSON.stringify(this.updateEvent.value));   // localStorage.setItem('id', noOfClicks);
      this.loadCities();
    }else{
      const lead = JSON.parse(sessionStorage.getItem("selectedEvent"));
      console.log("Got From local storage",lead);
      this.SetEventData(lead);
     this.loadCities();
      //console.log("Selected Field",this.UpdateLeadForm.controls['ProductId'].value)
    }

    
  }
  BuildForm(){
    this.updateEvent = this.formBuilder.group({
      Id: ["", Validators.required],
      EventName: ["", Validators.required],
      CountryCode:"",
      CountryID:[null,Validators.required],
      StartDate: ["", Validators.required],
      EndDate: ["", Validators.required],
      PlaceId:  ["", Validators.required],
      EventCode:["", Validators.required]
  });
  }
  SetEventData(data){
    this.updateEvent.controls['Id'].setValue(data.Id);
    this.updateEvent.controls['EventName'].setValue(data.EventName);
    this.updateEvent.controls['CountryCode'].setValue(data.CountryCode);
    this.updateEvent.controls['StartDate'].setValue(data.StartDate);
    this.updateEvent.controls['EndDate'].setValue(data.EndDate);
    this.updateEvent.controls['PlaceId'].setValue(+data.PlaceId);
    this.updateEvent.controls['EventCode'].setValue(data.EventCode);
  }
  public UpdateEvent() {
    let _payload=Object.assign({},this.updateEvent.value);
    const d = new Date(_payload.StartDate)
    // This will return an ISO string matching your local time.
    const _dateStart=new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString()
    const e = new Date(_payload.EndDate)
    // This will return an ISO string matching your local time.
    const _dateEnd=new Date(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes() - e.getTimezoneOffset()).toISOString()
    _payload.StartDate=_dateStart;
    _payload.EndDate=_dateEnd;
    this.httpService.postData('/api/Setup/updateEventbyID?EventID='+this.updateEvent.controls['Id'].value,_payload).subscribe( data => {
      if (data) {
        this.router.navigate(['/table-list'])
      }
    })
      this.helperService.shiftEdited.next()
  }
}