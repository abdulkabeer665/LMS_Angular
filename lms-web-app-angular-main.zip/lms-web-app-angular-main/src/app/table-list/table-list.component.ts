import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from 'app/Services/helper.service';
import { HttpService } from 'app/Services/http-service.service';
import { LoaderService } from 'app/Services/loader.service';
import { Subject, takeUntil } from 'rxjs';
import { format, parseISO } from 'date-fns'
import { MatDialog } from '@angular/material/dialog';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';


@Component({
  selector: 'app-table-list',
  templateUrl: './table-list.component.html',
  styleUrls: ['./table-list.component.css']
})
export class TableListComponent implements OnInit {
  paginationdata: any;
  eventsData: any;
  searchText:string = '';
  searchvalue:string='EventName';
  totalCount=0;
  totalresult:string;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  page:number;
  private unsubscribe: Subject<void> = new Subject();
  
  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:PageEvent){
    this.getAllEvents(+(event.pageIndex+1),event.pageSize)
  }
 
  constructor(public httpservice : HttpService,public router : Router,
    private loader: LoaderService, public helperService : HelperService,private dialog:MatDialog) { }

  ngOnInit() {
   
    
    this.getAllEvents(1,25);

    this.helperService.shiftEdited
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(() => {
        this.getAllEvents(1,5);
      });
     
  }

 public clickToEdit(i) : void {

  const param = i
this.router.navigate(['/edit-event'],{ state: { Event: param }})  }

public createEvent() {
  this.router.navigate(['//add-event'])
}

public getAllEvents(pageNumber,pageSize) : void {
  this.httpservice.getData('/api/Setup/getAllEvents?PageNumber='+pageNumber+"&RowsOfPage="+pageSize).subscribe(data => {
      if (data) {
        this.totalCount=data['data']["length"];
          this.eventsData=data['data']
          console.log(data, 'this is eventdata', this.totalCount,'this.is data count')
      }
  })
}

public deleteEvents(id:any){
  // this.httpservice.postData(`/api/Setup/deleteEventsByID?EventID=${id}`,id).subscribe((data:any)=>{
  //   this.getAllEvents();
  // })
  this.dialog.open(DeleteEventComponent,{
    width:'390px',
    data:{
      message:'Are you sure to delete this event ?'
    }

  }).afterClosed().subscribe((res:any)=>{
    if(res === true){
       this.httpservice.postData(`/api/Setup/deleteEventsByID?EventID=${id}`,id).subscribe((data:any)=>{
    this.getAllEvents(1,5);
  })
    }
  });
  
    }

    formatDate(value) {
      return format(parseISO(value), 'dd-MM-yyyy' );
    }
}


