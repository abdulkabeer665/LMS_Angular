import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { HttpService } from "app/Services/http-service.service";
import { first } from "rxjs";

@Component({
  selector: "app-add-event",
  templateUrl: "./add-event.component.html",
  styleUrls: ["./add-event.component.css"],
})
export class AddEventComponent implements OnInit {
  createEvent: FormGroup;
  show:boolean = false;
  countries: any;
  // code:string;
  // id: any;
  item: string;
  data=[];
  places=[];
  placeId: any;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public httpService: HttpService
  ) {
    this.httpService.getData('/api/Setup/getLookupDatabyCode?Code=Country_Master').subscribe((x:any ) => {
      if(x.data && x.data['length']){
        this.data = x['data'];
      }else{
        this.data = [];
      }
    })
  }

  onCountryChange(value : any){
    // this.code = value.Code
    // this.id = value.Id
     this.httpService.getData('/api/Setup/getLookupDatabyCode?Code='+this.createEvent.controls['CountryCode'].value).subscribe((x:any ) => {
       
       if(x.data && x.data['length']){
        this.places = x['data'];
      }else{
        this.places = [];
      }
     })
   }

   onPlaceChanges(value : any) {
      this.placeId = value.Id
      // this.createEvent.controls['PlaceId'].setValue(this.placeId) 
   }

  ngOnInit(): void {
    this.createEvent = this.formBuilder.group({
      EventName: ["", Validators.required],
      StartDate: ["", Validators.required],
      EndDate: ["", Validators.required],
      CountryCode:["",Validators.required],
      PlaceId:  ["", Validators.required],
      EventCode:["", Validators.required]
    });
  }

  onSubmit() {
    if(this.createEvent.valid){
      let _payload=Object.assign({},this.createEvent.value);
      const d = new Date(_payload.StartDate)
      // This will return an ISO string matching your local time.
      const _dateStart=new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString()
      const e = new Date(_payload.EndDate)
      // This will return an ISO string matching your local time.
      const _dateEnd=new Date(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes() - e.getTimezoneOffset()).toISOString()
      _payload.StartDate=_dateStart;
      _payload.EndDate=_dateEnd;
      this.httpService
        .postData("/api/Setup/insertEvent", _payload)
        .pipe(first())
        .subscribe((data) => {
          if (data) {
            this.router.navigate(["/table-list"]);
          }
        });
    }
  }
  

 
}
