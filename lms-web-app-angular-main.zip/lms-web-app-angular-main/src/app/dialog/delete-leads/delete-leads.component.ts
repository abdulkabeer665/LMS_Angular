import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-leads',
  templateUrl: './delete-leads.component.html',
  styleUrls: ['./delete-leads.component.scss']
})
export class DeleteLeadsComponent implements OnInit {

  constructor(private dialog:MatDialog,@Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit(): void {
  }
  dialogclose(){
    this.dialog.closeAll();
    }
}
