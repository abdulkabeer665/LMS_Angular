import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-lead',
  templateUrl: './create-lead.component.html',
  styleUrls: ['./create-lead.component.scss']
})
export class CreateLeadComponent implements OnInit {

  constructor(public router : Router) { }

  ngOnInit(): void {
  }

  public createLead(): void {
    this.router.navigate(['lms-leads'])
  }
}
