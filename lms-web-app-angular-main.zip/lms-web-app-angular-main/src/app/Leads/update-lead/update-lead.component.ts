import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-lead',
  templateUrl: './update-lead.component.html',
  styleUrls: ['./update-lead.component.scss']
})
export class UpdateLeadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
