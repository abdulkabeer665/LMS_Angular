import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lms-leads',
  templateUrl: './leads.component.html',
  styleUrls: ['./leads.component.css']
})
export class LeadsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
