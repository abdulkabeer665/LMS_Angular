import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateLeadComponent } from './create-lead/create-lead.component';
import { UpdateLeadComponent } from './update-lead/update-lead.component';
import { LeadOverviewComponent } from './lead-overview/lead-overview.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { LeadsComponent } from './leads.component';


const routes: Routes = [
  {
    path: 'lms-leads',
    component: LeadsComponent
  },
  {
    path: 'leads-overview',
    component: LeadOverviewComponent
  },
  {
    path: 'create-Leads',
    component: CreateLeadComponent
  },
  {
    path: 'update-leads',
    component: UpdateLeadComponent
  }
]

@NgModule({
  declarations: [
    CreateLeadComponent,
    UpdateLeadComponent,
    LeadOverviewComponent,
 
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
  ]
})
export class LeadsModule { }
