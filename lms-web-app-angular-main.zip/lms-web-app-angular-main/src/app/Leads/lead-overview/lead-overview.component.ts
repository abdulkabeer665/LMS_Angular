import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lead-overview',
  templateUrl: './lead-overview.component.html',
  styleUrls: ['./lead-overview.component.scss']
})
export class LeadOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
