// export interface PaginatedResponse<T> {
//     items: T[];
//     total: number;
//   }
//   public pageSize = 10;
//   private readonly items = Array.from(
//     Array(100).keys(),
//     (item) => item + 1
//   );
//   public visibleItems: PaginatedResponse<number> = {
//     items: this.items.slice(0, this.pageSize),
//     total: this.items.length,
//   };