import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/Services/http-service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-role-rights',
  templateUrl: './user-role-rights.component.html',
  styleUrls: ['./user-role-rights.component.scss']
})
export class UserRoleRightsComponent implements OnInit {
  ScreenData=[];
  data=[];
  index:any;
  dataPost=[];
  roleName="";
  Id:string;
  pageNumber:any = 1;
  pageSize:any = 25;
  check:boolean=true;
  check2:boolean=false;
  constructor(public httpService: HttpService,private route: ActivatedRoute) {
    this.httpService.getData('/api/Setup/getLookupDatabyCode?Code=Menu_Master&PageNumber='+this.pageNumber+"&RowsOfPage="+this.pageSize).subscribe((x:any ) => {
      this.data = x.data
      console.log(this.data)
      for (var i=0; i < this.data.length; i++){
        this.data[i].R = false;
        this.data[i].W = false;
        this.data[i].U = false;
        this.data[i].D = false;
      }
      console.log(this.data)
    })
   }


  ngOnInit(): void {
      this.Id = this.route.snapshot.paramMap.get('Id');
    this.httpService.getData('/api/Setup/getRoleDetailsById?ID='+this.Id).subscribe((x:any) =>{
      this.data = x.data
      if(this.Id !== null){
        this.check2 = true
        this.check = false
      }else{
        this.check = false
        this.check2 = true
      }
      
    })

    
    console.log("this is your param = ", this.Id)
    console.log("this is your updateData = ", this.data,this.roleName,this.check)
    
    
  }

  handleData(){
      
  }
  submit(){
    const body = this.data;
    const roleName = this.roleName
    this.httpService.postData('/api/Setup/AddNewRole?RoleName='+roleName,body).subscribe((x =>{ 
      console.log(this.data,"new obj created",this.roleName)
    }))
  }
  update(){
    const body =  this.data
    const param = this.Id
    this.httpService.postData('/api/Setup/UpdateUserRoleRights?RoleId='+param,body).subscribe((x =>{
      console.log(this.data,"data updated",param)
    }))
  }
}
