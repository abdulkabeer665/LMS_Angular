import { Routes } from "@angular/router";

import { DashboardComponent } from "../../dashboard/dashboard.component";
import { UserProfileComponent } from "../../user-profile/user-profile.component";
import { TableListComponent } from "../../table-list/table-list.component";
import { TypographyComponent } from "../../typography/typography.component";
import { IconsComponent } from "../../icons/icons.component";
import { MapsComponent } from "../../maps/maps.component";
import { NotificationsComponent } from "../../notifications/notifications.component";
import { UpgradeComponent } from "../../upgrade/upgrade.component";
import { LoginComponent } from "app/components/login/login.component";
import { EditLeadsComponent } from "app/upgrade/edit-leads/edit-leads.component";
import { AddEventComponent } from "app/table-list/add-event/add-event.component";
import { EditEventComponent } from "app/table-list/edit-event/edit-event.component";
import { UserGirdComponent } from "app/user-profile/user-gird/user-gird.component";
import { UserEditComponent } from "app/user-profile/user-edit/user-edit.component";

import { UserroleComponent } from 'app/userrole/userrole.component';
import { ProductsComponent } from 'app/products/products.component';
import { IndustriesComponent } from 'app/industries/industries.component';
import { PrioritesComponent } from 'app/priorites/priorites.component';
import { UserRoleRightsComponent } from 'app/user-role-rights/user-role-rights.component';
import { PlacesComponent } from "app/places/places.component";
import { FollowupComponent } from "app/followup/followup.component";

export const AdminLayoutRoutes: Routes = [
  { path: "dashboard", component: DashboardComponent },
  { path: "user-profile", component: UserGirdComponent },
  { path: "table-list", component: TableListComponent },
  { path: "typography", component: TypographyComponent },
  { path: "icons", component: IconsComponent },
  { path: "maps", component: MapsComponent },
  { path: "notifications", component: NotificationsComponent },
  { path: "upgrade", component: UpgradeComponent },
  { path: "edit-leads", component: EditLeadsComponent },
  { path: "add-event", component: AddEventComponent },
  { path: "edit-event", component: EditEventComponent },
  { path: "create-user", component: UserProfileComponent },
  { path: "update-user", component: UserEditComponent },
    {path: 'places',          component:PlacesComponent},
    {path: 'products',        component:ProductsComponent},
    {path: 'industries',      component:IndustriesComponent},
    {path: 'priorities',      component:PrioritesComponent},
    {path: 'followup',        component:FollowupComponent},
    {path: 'rolerights/:Id',      component:UserRoleRightsComponent},
    {path:'user-roles',component:UserroleComponent}
];
