
import { IndustriesComponent } from 'app/industries/industries.component';
import { PrioritesComponent } from 'app/priorites/priorites.component';
import { ProductsComponent } from 'app/products/products.component';
import { UserroleComponent } from 'app/userrole/userrole.component';
import { UserRoleRightsComponent } from 'app/user-role-rights/user-role-rights.component';
import { UpgradeComponent } from 'app/upgrade/upgrade.component';
import {MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AdminLayoutRoutes } from "./admin-layout.routing";
import { DashboardComponent } from "../../dashboard/dashboard.component";
import { UserProfileComponent } from "../../user-profile/user-profile.component";
import { TypographyComponent } from "../../typography/typography.component";
import { IconsComponent } from "../../icons/icons.component";
import { MapsComponent } from "../../maps/maps.component";
import { NotificationsComponent } from "../../notifications/notifications.component";
import { LeadsComponent } from "../../Leads/leads.component";
import { MatButtonModule } from "@angular/material/button";
import { MatInputModule } from "@angular/material/input";
import { MatRippleModule } from "@angular/material/core";
import { MatFormFieldModule, MatHint } from "@angular/material/form-field";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatSelectModule } from "@angular/material/select";
import { LMSGridComponent } from "app/components/LMS-grid/lms-grid.component";
import { EventComponent } from "app/Events/event.component";
import { EditLeadsComponent } from "app/upgrade/edit-leads/edit-leads.component";
import { MatRadioModule } from "@angular/material/radio";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { AddEventComponent } from "app/table-list/add-event/add-event.component";
import { EditEventComponent } from "app/table-list/edit-event/edit-event.component";
import { TableListComponent } from "app/table-list/table-list.component";

import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { UserEditComponent } from "app/user-profile/user-edit/user-edit.component";
import { PlacesComponent } from 'app/places/places.component';
import { FollowupComponent } from 'app/followup/followup.component';
import { NgProgressModule } from 'ngx-progressbar';
import { NgProgressHttpModule } from "ngx-progressbar/http";
import {MatPaginatorModule} from '@angular/material/paginator';
import { FilterPipe } from 'app/pipes/filter.pipe';

import {MatDialogModule} from '@angular/material/dialog';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
import {MatIconModule} from '@angular/material/icon';
import { DeleteUserComponent } from 'app/dialog/delete-user/delete-user.component';
import { DeleteLeadsComponent } from 'app/dialog/delete-leads/delete-leads.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { UserGirdComponent } from 'app/user-profile/user-gird/user-gird.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatDialogModule,
    MatIconModule,
    MatSnackBarModule,
  
    // NgProgressModule.withConfig({
    //   color: '#D61921'
    // }),
    // NgProgressHttpModule
  ],
  declarations: [
    DashboardComponent,
    UserProfileComponent,
    EventComponent,
    TypographyComponent,
    IconsComponent,
    MapsComponent,
    NotificationsComponent,
    LeadsComponent,
    LMSGridComponent,
    EditLeadsComponent,
    AddEventComponent,
    EditEventComponent,
    TableListComponent,
    UpgradeComponent,
    UserEditComponent,
    FollowupComponent,
    IndustriesComponent,
    PlacesComponent,
    PrioritesComponent,
    UserRoleRightsComponent,
    ProductsComponent,
    UserroleComponent,
    FilterPipe,
    DeleteEventComponent,
    DeleteUserComponent,
    DeleteLeadsComponent,
    UserGirdComponent
  ],
  entryComponents: [DeleteEventComponent,DeleteUserComponent,DeleteLeadsComponent]
})
export class AdminLayoutModule {}
