import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from 'app/Services/http-service.service';
import { param } from 'jquery';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.scss']
})
export class UserEditComponent implements OnInit {
  myParam: string;
  id: any;
  UserId: any;
  UpdateUserform: FormGroup;
  loading = false;
  submitted = false;
  UserData: any;
  UserDataToBind: any;
  roles: any;
  item : any;
  roleID: any;

  constructor(private route: ActivatedRoute, public httpService : HttpService,private formBuilder: FormBuilder, private router: Router,private location: Location
    ) { }

    public onRoleChanges(value : any) {
      this.roleID = value.Id
      this.UpdateUserform.controls['roleID'].setValue(this.roleID)

   }

  ngOnInit(): void {

    // this.UserData = this.router.getCurrentNavigation().extras.state.User 
   this.UserData= this.location.getState();
   this.UserDataToBind = this.UserData?.User;
   this.getRoles()

    this.UpdateUserform = this.formBuilder.group({
      id : this.UserData?.User?.Id,
      name: ['', Validators.required],
      fullName: ['', Validators.required],
      mobile : ['', Validators.required],
      email : ['', Validators.required],
      roleID: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
  });
  }

  public update() {
      this.httpService.postData('/api/UserAccount/UpdateUserById',this.UpdateUserform.value).pipe().subscribe( data => {
        if (data) {
          this.router.navigate(['/user-profile']);
        }
      })
  }

  public getRoles() {
    this.httpService.getData('/api/Setup/getRoles').subscribe( data => {
        this.roles = data['data']
    })
  }
  }
