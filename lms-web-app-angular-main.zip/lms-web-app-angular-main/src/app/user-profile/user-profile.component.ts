import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomvalidationService } from 'app/Services/customvalidation.service';
import { HttpService } from 'app/Services/http-service.service';
import { first } from 'rxjs';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  form: FormGroup;
  loading = false;
  submitted = false;
  roles : any;
  item : any;
  roleID: any;
  constructor( private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public httpService : HttpService,
    public customValidatorService : CustomvalidationService) { }

    public onRoleChanges(value : any) {
       this.roleID = value.Id
       this.form.controls['roleID'].setValue(this.roleID)

    }

  ngOnInit() {
    this.getRoles();
    this.form = this.formBuilder.group({
      name: ['', Validators.required],
      fullName: ['', Validators.required],
      mobile : ['', Validators.required],
      email : ['', Validators.required],
      roleID: ['', Validators.required],
      password: new FormControl('',Validators.compose([Validators.required, this.customValidatorService.patternValidator()])),
      confirmPassword:new FormControl('',[Validators.required]),
  },
  {
    validator: this.customValidatorService.MatchPassword('password', 'confirmPassword'),
  }

  
  );
  }
  get registerFormControl() {
    return this.form.controls;
  } 
  public onSubmit() {
    this.submitted = true;

    // reset alerts on submit
    // this.alertService.clear();

    // stop here if form is invalid
    if (this.form.invalid) {
        return;
    }

    this.loading = true;

    this.httpService.postData('/api/UserAccount/register',this.form.value).pipe(first()).subscribe(data => {
      if (data) {
        this.router.navigate(['/user-profile']);

      }
    })

}

public getRoles() {
  this.httpService.getData('/api/Setup/getRoles').subscribe( data => {
      this.roles = data['data']
  })
}

}
