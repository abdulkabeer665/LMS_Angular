import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { DeleteUserComponent } from 'app/dialog/delete-user/delete-user.component';
import { HttpService } from 'app/Services/http-service.service';
import { LoaderService } from 'app/Services/loader.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-user-gird',
  templateUrl: './user-gird.component.html',
  styleUrls: ['./user-gird.component.scss']
})
export class UserGirdComponent implements OnInit {
  UsersData: any;
  searchvalue:string = 'Name'; 
  searchText:string = '';
  isLoading: Subject<boolean> = this.loader.isLoading;
  userParamId: any;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  totalCount:0;
  data=[];


  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:any){
    this.getAllUsers(+(event.pageIndex+1),event.pageSize)
   
  }

  constructor(public httpservice : HttpService,public router : Router,
    private loader: LoaderService,private dialog:MatDialog) { }

  ngOnInit(): void {
    this.getAllUsers(1,25);
    
  }


  public getAllUsers(pageNumber , pageSize) : void {
    this.httpservice.getData('/api/Setup/getAllUsers?PageNumber='+pageNumber+"&RowsOfPage="+pageSize).subscribe( x => {
    if (x ) {
      this.UsersData = x['data']
      this.totalCount = x['data']['length']
      console.log(this.UsersData , this.totalCount ,'this.is test obj');

    }else{
      console.log('this is else')
    }
      // this.data=[];
      //       if(x && x.data && x.data['length']){
      //         this.data = x.data
      //         this.totalCount = x.data['length']
      //       }

    })
  }

  public createUser() : void {
    this.router.navigate(['/create-user'])
  }

  cellClicked(i) {
    const param = i
this.router.navigate(['/update-user'],{ state: { User: param }})

  }
  deleteuser(id:any){
    this.dialog.open(DeleteUserComponent,{
      width:'390px',
      data:{
        message:'Are you sure to delete this user ?'
      }
  
    }).afterClosed().subscribe((res:any)=>{
      if(res === true){
         this.httpservice.postData(`/api/Setup/deleteUserbyID?UserId=${id}`,id).subscribe((data:any)=>{
      this.getAllUsers(1,25);
    })
      }
    });
  }
}
