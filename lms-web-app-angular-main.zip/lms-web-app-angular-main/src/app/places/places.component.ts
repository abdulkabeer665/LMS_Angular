import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
import { HttpService } from 'app/Services/http-service.service';
import {MatSnackBar} from '@angular/material/snack-bar';


@Component({
  selector: 'app-places',
  templateUrl: './places.component.html',
  styleUrls: ['./places.component.css']
})
export class PlacesComponent implements OnInit {
  show:boolean = false;
  countries: any;
  code:string;
  id: any;
  item: string;
  data=[];
  grid=[];
  InsertCountryform:FormGroup;
  editRowNum=-1;
  editRow;
  totalCount=0;
  searchText:string = '';
  searchvalue:string='NameEn';
 
  key:string='NameEn';
  pageSizeOptions: number[] = [5, 10, 25, 100];


  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:any){
    this.loadCities(+(event.pageIndex+1),event.pageSize)
   
  }
  constructor(public httpService: HttpService ,private formBuilder: FormBuilder ,private dialog:MatDialog,
    private _snackBar: MatSnackBar) { 
      this.httpService.getData('/api/Setup/getLookupDatabyCode?Code=Country_Master&PageNumber=1&RowsOfPage=1000').subscribe((x:any ) => {
        this.data = x.data
        
      })
  }
 
  onCountryChange(){
   this.code = this.item['Code']
   this.id = this.item['Id'];
   this.InsertCountryform.controls['CountryId'].setValue(this.id);
    this.loadCities(1,25);
  }
  loadCities(pageNumber, pageSize){
    this.httpService.getData('/api/Setup/getLookupDatabyCode?Code='+this.code+"&PageNumber="+pageNumber+"&RowsOfPage="+pageSize).subscribe((x:any ) => {
      this.grid = [];
      if(x.data && x.data['length']){
        this.grid = x.data;
        this.totalCount = x.data.length
        console.log(this.grid, "this is palaces count",this.totalCount)
      }
      console.log(this.grid)
      
    })
  }
  ngOnInit(): void {
    this.InsertCountryform = this.formBuilder.group({
      CountryId: ['', Validators.required],
      Code: '',
      NameEn : ['', Validators.required],
      NameAr : '',
  });

 
  }
 

  public InsertCountry(){
    if(this.InsertCountryform.valid){
      this.InsertCountryform.controls['Code'].setValue(this.code+'_'+((this.InsertCountryform.controls['NameEn'].value+'').toLowerCase()));
      this.httpService.postData('/api/Setup/insertPlacebyCountryID',this.InsertCountryform.value).subscribe((x =>{
        this.loadCities(1,25);
      }))
    }
    
  }
  startEditing(rowNumber,data){
    this.editRow=data;
    this.editRowNum=rowNumber;
  }
  validationOnEditMode=false;
  updateRow(){
    this.validationOnEditMode=false;
    if(this.editRow.NameEn && this.editRow.NameEn!=''){
      this.updatePlace();
    }else{
      this.validationOnEditMode=true;;
    }
  }
  updatePlace(){
    this.editRow.Code='place_'+((this.editRow.NameEn+'').toLowerCase())
    this.httpService.postData('/api/Setup/updateLookupbyId?Id='+this.editRow.Id,this.editRow).subscribe((x =>{
      this.loadCities(1,25)
      this.cancelEditing();
    }))
  }
  cancelEditing(){
    this.editRowNum=-1;
    this.editRow=undefined;
    
  }
  deletePlace(id,){
    this.dialog.open(DeleteEventComponent,{
      width:'390px',
      data:{
        message:'Are you sure to delete this Place ?'
      }
  
    }).afterClosed().subscribe((res:any)=>{
      if(res === true){
         this.httpService.deleteData(`/api/Setup/deleteLookupbyId?Id=${id}`).subscribe((data:any)=>{
          console.log("Record Deleted:",data);
          if(data && data.result=='success'){
            this.InsertCountryform.reset();
            this.loadCities(1,25);
          }else if(data && data.result=='faild'){
            this.openSnackBar("Cannot Delete Record!");
          }
          
        })
      }
    });
  }
  openSnackBar(message: string) {
    this._snackBar.open(message,'ok',{
      duration: 3000
    });
  }
  
}
