import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/Services/http-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DeleteEventComponent } from 'app/dialog/delete-event/delete-event.component';
@Component({
  selector: 'app-industries',
  templateUrl: './industries.component.html',
  styleUrls: ['./industries.component.css']
})
export class IndustriesComponent implements OnInit {
  InsertIndustryform : FormGroup;
  data=[];
  editRowNum=-1;
  editRow;
  searchText:string = '';
  searchvalue:string = 'NameEn';
  pageSizeOptions: number[] = [5, 10, 25, 100];
  totalCount:0;

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  pageEventChange(event:any){
    this.load(+(event.pageIndex+1),event.pageSize)
   
  }
  constructor(public httpService: HttpService,private formBuilder: FormBuilder,private dialog:MatDialog,
    private _snackBar: MatSnackBar) {
   
   }

  ngOnInit(): void {
    this.load(1,5);
    this.InsertIndustryform = this.formBuilder.group({
      LookUpDataCode: 'Industry_Master',
      Code:'',
      NameEn : ['', Validators.required],
      NameAr : '',
  });
  }

  load(pageNumber, pageSize){
    this.httpService.getData('/api/Setup/getLookupDatabyCode?Code=Industry_Master'+"&PageNumber="+pageNumber+"&RowsOfPage="+pageSize).subscribe((x:any ) => {
      this.data=[];
      if(x && x.data && x.data['length']){
        this.data = x.data
        this.totalCount = x.data['length']
      }
    })
  }


  InsertIndustry(){
    this.InsertIndustryform.controls['Code'].setValue('product_'+((this.InsertIndustryform.controls['NameEn'].value+'').toLowerCase()))
    this.httpService.postData('/api/Setup/insertLookup',this.InsertIndustryform.value).subscribe((x =>{
      this.load(1,25);
    }))
  }
  startEditing(rowNumber,data){
    this.editRow=data;
    this.editRowNum=rowNumber;
    console.log(data)
  }
  validationOnEditMode=false;
  updateRow(){
    this.validationOnEditMode=false;
    if(this.editRow.NameEn && this.editRow.NameEn!=''){
      this.updateIndustry();
    }else{
      this.validationOnEditMode=true;;
    }
  }
  updateIndustry(){
    this.editRow.Code='industry_'+((this.editRow.NameEn+'').toLowerCase())
    this.httpService.postData('/api/Setup/updateLookupbyId?Id='+this.editRow.Id,this.editRow).subscribe((x =>{
      this.load(1,25);
      this.cancelEditing();
    }))
  }
  cancelEditing(){
    this.editRowNum=-1;
    this.editRow=undefined;
    
  }
  deleteIndustries(id,){
    this.dialog.open(DeleteEventComponent,{
      width:'390px',
      data:{
        message:'Are you sure to delete?'
      }
  
    }).afterClosed().subscribe((res:any)=>{
      if(res === true){
         this.httpService.deleteData(`/api/Setup/deleteLookupbyId?Id=${id}`).subscribe((data:any)=>{
          console.log("Record Deleted:",data);
          if(data && data.result=='success'){
            this.InsertIndustryform.reset();
            this.load(1,25);
          }else if(data && data.result=='faild'){
            this.openSnackBar("Cannot Delete Record!");
          }
          
        })
      }
    });
  }
  openSnackBar(message: string) {
    this._snackBar.open(message,'ok',{
      duration: 3000
    });
  }
  
}
